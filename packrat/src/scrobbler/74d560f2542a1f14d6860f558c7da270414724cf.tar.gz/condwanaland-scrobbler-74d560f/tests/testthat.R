library(testthat)
library(scrobbler)

test_check("scrobbler")
